#' Interactive bipartite graphs
#'
#'
#' @name bipartiteD3
#' @docType package
NULL
