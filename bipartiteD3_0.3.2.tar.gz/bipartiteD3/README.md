README

A package to generate interactive bipartite graphs using the D3 library.
    Designed for use with the 'bipartite' analysis package.
    Sources open source 'vis-js' library (<visjs.org/>).
    Adapted from examples at <bl.ocks.org/NPashaP> bl.ocks (released under GPL-3)
    
    Works best with RStudio v1.2+

Check vignette for examples and discussion
